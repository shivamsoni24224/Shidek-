╔══════════════════════════════════════════╗
║         SHIDEK PWA – Setup Guide        ║
╚══════════════════════════════════════════╝

📁 Files in this folder:
  index.html     → Main app
  manifest.json  → PWA config
  sw.js          → Offline support
  icons/         → App icons
  README.txt     → This file

🚀 GitHub Pages પર Host કરવાના Steps:

STEP 1: github.com પર Free account બનાવો

STEP 2: New Repository બનાવો
  → Repository name: shidek
  → Public રાખો
  → Create repository

STEP 3: આ folder ની બધી files upload કરો
  → "uploading an existing file" ક્લિક કરો
  → બધી files drag & drop કરો
  → Commit changes

STEP 4: GitHub Pages Enable કરો
  → Settings → Pages
  → Source: main branch → / (root)
  → Save

STEP 5: તમારી App Live થઈ!
  URL: https://[username].github.io/shidek

📱 Phone પર Install કરવા:
  Android: Chrome → ⋮ → "Add to Home screen"
  iPhone:  Safari → Share → "Add to Home Screen"

✅ Done! SHIDEK હવે App જેવું જ કામ કરશે!
